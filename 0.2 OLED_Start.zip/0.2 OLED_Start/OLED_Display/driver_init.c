#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

// A "TARGET device" refers to the SAMD51 MCU that the software is intended to run on.
struct usart_sync_descriptor TARGET_IO;

void TARGET_IO_PORT_init(void){
	gpio_set_pin_function(TX_PIN, PINMUX_PB02D_SERCOM5_PAD0);
	gpio_set_pin_function(RX_PIN, PINMUX_PB03D_SERCOM5_PAD1);
}

void TARGET_IO_CLOCK_init(void){
	
	// Writing enable bit to the Peripheral Channel Control (PCHCTRL) register of the Generic Clock (GCLK) module to configure the source for SERCOM5 'Core' Clock
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM5_GCLK_ID_CORE, CONF_GCLK_SERCOM5_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	
	// Writing enable bit to the Peripheral Channel Control (PCHCTRL) register of the Generic Clock (GCLK) module to configure the source for SERCOM5 'Slow' Clock
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM5_GCLK_ID_SLOW, CONF_GCLK_SERCOM5_SLOW_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	
	// Enable the SERCOM5 peripheral by setting the corresponding bit in the APBDMASK register of the Main Clock (MCLK) module
	hri_mclk_set_APBDMASK_SERCOM5_bit(MCLK);
}

void TARGET_IO_init(void){
	
	// Initialize the target I/O clock configuration
	TARGET_IO_CLOCK_init();
	
	// Initialize USART communication on the target I/O using SERCOM5
	// Parameters: USART module instance (TARGET_IO), SERCOM5 peripheral, pointer to configuration settings (NULL in this case)
	usart_sync_init(&TARGET_IO, SERCOM5, (void *)NULL);
	
	// Initialize the port configuration for the target I/O
	TARGET_IO_PORT_init();
}

void delay_driver_init(void){delay_init(SysTick);}

void stdio_redirect_init(void)
{
	usart_sync_enable(&TARGET_IO);
	stdio_io_init(&TARGET_IO.io);
}

void system_init(void){
	
	init_mcu();

	TARGET_IO_init();
	stdio_redirect_init();
	
	delay_driver_init();
	
	SSD1351_init();				// OLED DISPLAY CONTROLLER
}
