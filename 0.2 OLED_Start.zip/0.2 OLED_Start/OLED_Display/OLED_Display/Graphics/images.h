#ifndef IMAGES_H_
#define IMAGES_H_

#include <stdint.h>

// GRAPHIC DATA
extern const uint16_t image_data_company_trademark[];
extern const uint16_t image_data_gui_background[];
extern const uint16_t image_data_alert_22x22[];
extern const uint16_t image_data_arrow_left_22x22[];
extern const uint16_t image_data_arrow_right_22x22[];
extern const uint16_t image_data_sun_22x22[];
extern const uint16_t image_data_moon_22x22[];
#endif