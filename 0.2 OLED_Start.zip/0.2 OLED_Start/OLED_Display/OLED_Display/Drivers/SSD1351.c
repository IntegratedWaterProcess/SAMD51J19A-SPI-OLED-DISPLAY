#include "SSD1351.h"

#include <hal_io.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <hal_spi_m_sync.h>

static int16_t cursor_x;     ///< x location to start print()ing text
static int16_t cursor_y;     ///< y location to start print()ing text
static uint16_t textcolor;   ///< 16-bit background color for print()
static uint16_t textbgcolor; ///< 16-bit text color for print()
static uint8_t textsize_x;   ///< Desired magnification in X-axis of text to print()
static uint8_t textsize_y;   ///< Desired magnification in Y-axis of text to print()
static uint8_t rotation;     ///< Display rotation (0 thru 3)

struct spi_m_sync_descriptor OLED_SPI;

static struct io_descriptor *io;

// INIT DISPLAY ------------------------------------------------------------

static const uint8_t initList[] = {
	SSD1351_CMD_COMMANDLOCK,
	1, // Set command lock, 1 arg
	0x12,
	SSD1351_CMD_COMMANDLOCK,
	1, // Set command lock, 1 arg
	0xB1,
	SSD1351_CMD_DISPLAYOFF,
	0, // Display off, no args
	SSD1351_CMD_CLOCKDIV,
	1,
	0xF0, // 7:4 = Oscillator Freq, 3:0 = CLK Div Ratio (A[3:0]+1 = 1..16), "approx 90fps"
	SSD1351_CMD_MUXRATIO,
	1,
	127,
	SSD1351_CMD_DISPLAYOFFSET,
	1,
	0x0,
	SSD1351_CMD_SETGPIO,
	1,
	0x00,
	SSD1351_CMD_FUNCTIONSELECT,
	1,
	0x01, // internal (diode drop)
	SSD1351_CMD_PRECHARGE,
	1,
	0x32,
	SSD1351_CMD_VCOMH,
	1,
	0x05,
	SSD1351_CMD_NORMALDISPLAY,
	0,
	SSD1351_CMD_CONTRASTABC,
	3,
	0xC8,
	0x80,
	0xC8,
	SSD1351_CMD_CONTRASTMASTER,
	1,
	0x0F,
	SSD1351_CMD_SETVSL,
	3,
	0xA0,
	0xB5,
	0x55,
	SSD1351_CMD_PRECHARGE2,
	1,
	0x01,
	SSD1351_CMD_DISPLAYON,
	0,  // Main screen turn on
0}; // END OF COMMAND LIST


void SPI_DC_LOW()
{
	gpio_set_pin_level(OLED_DC_PIN, false);
}

void SPI_DC_HIGH()
{
	gpio_set_pin_level(OLED_DC_PIN, true);
}

void SPI_CS_LOW()
{
	gpio_set_pin_level(OLED_CS_PIN, false);
}

void SPI_CS_HIGH()
{
	gpio_set_pin_level(OLED_CS_PIN, true);
}

/**
 * \brief Write a command to the display controller
 */
void SSD1351_write_command(const uint8_t command)
{
	SPI_DC_LOW();
	io_write(io, &command, 1);
	SPI_DC_HIGH();
}

/**
 * \brief Write data to the display controller register
 */
void SSD1351_write_data(const uint8_t data)
{
	SPI_DC_HIGH();
	io_write(io, &data, 1);
}


/**
 * \brief Perform a hard reset of the display controller
 */
void SSD1351_hard_reset(void)
{
	gpio_set_pin_level(OLED_RST_PIN, false);
	delay_ms(1);
	gpio_set_pin_level(OLED_RST_PIN, true);
	delay_ms(1);
}

/*!
@brief   Adafruit_SPITFT Send Command handles complete sending of commands and
data
@param   commandByte       The Command Byte
@param   dataBytes         A pointer to the Data bytes to send
@param   numDataBytes      The number of bytes we should send
*/
void SSD1351_sendCommand(uint8_t commandByte, const uint8_t *dataBytes,
                                  uint8_t numDataBytes) {
    // drive slave select low
	SPI_CS_LOW();

	SSD1351_write_command(commandByte); // Send the command byte

	for (int i = 0; i < numDataBytes; i++) {
		SSD1351_write_data(*dataBytes); // Send the data bytes
		dataBytes++;
	}

    // return slave select to high
    SPI_CS_HIGH();
}

void OLED_SPI_init(void)
{
	
	gpio_set_pin_direction(OLED_CS_PIN, GPIO_DIRECTION_OUT);	
	gpio_set_pin_function(OLED_CS_PIN, GPIO_PIN_FUNCTION_OFF);			// controlled by drivers
	//gpio_set_pin_function(OLED_CS_PIN, PINMUX_PA18C_SERCOM1_PAD2);	// controlled by SPI hardware, MSSEN=1
	gpio_set_pin_level(OLED_CS_PIN, true);
	
	// Writing enable bit to the Peripheral Channel Control (PCHCTRL) register of the Generic Clock (GCLK) to configure the source for SERCOM2 'CORE' Clock
	hri_gclk_write_PCHCTRL_reg(GCLK, SERCOM2_GCLK_ID_CORE, CONF_GCLK_SERCOM2_CORE_SRC | (1 << GCLK_PCHCTRL_CHEN_Pos));
	//_pm_enable_bus_clock(PM_BUS_APBC, SERCOM2); // Previous Command from SAMD21
	
	// Enable the SERCOM 2 peripheral by setting the corresponding bit in the 'APBBMASK' register of the Main Clock (MCLK) module	
	hri_mclk_set_APBBMASK_SERCOM2_bit(MCLK);
	//_gclk_enable_channel(SERCOM2_GCLK_ID_CORE, CONF_GCLK_SERCOM2_CORE_SRC); // Previous Command from SAMD21

	spi_m_sync_init(&OLED_SPI, SERCOM2);
	
	// PIN CONFIGURATION
	// MOSI
	gpio_set_pin_level(OLED_MOSI_PIN, false);
	gpio_set_pin_direction(OLED_MOSI_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(OLED_MOSI_PIN, PINMUX_PA12C_SERCOM2_PAD0);

	// SPI SERIAL CLOCK PIN
	gpio_set_pin_level(OLED_SCK_PIN, false);
	gpio_set_pin_direction(OLED_SCK_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(OLED_SCK_PIN, PINMUX_PA13C_SERCOM2_PAD1);

	// RESET PIN
	gpio_set_pin_direction(OLED_RST_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(OLED_RST_PIN, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_level(OLED_RST_PIN, false);	// active low reset, start reset

	// DATA COMMAND
	gpio_set_pin_direction(OLED_DC_PIN, GPIO_DIRECTION_OUT);
	gpio_set_pin_function(OLED_DC_PIN, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_level(OLED_DC_PIN, true);	// data mode default

	
	spi_m_sync_get_io_descriptor(&OLED_SPI, &io);
	spi_m_sync_enable(&OLED_SPI);
}

/**************************************************************************/
/*!
    @brief   Initialize SSD1351 chip
    Connects to the SSD1351 over SPI and sends initialization procedure commands
    @param   
*/
/**************************************************************************/

void SSD1351_init(void) {

	OLED_SPI_init();
	gpio_set_pin_level(OLED_RST_PIN, true);	// reset complete
	delay_ms(10);
		
	const uint8_t *addr = (const uint8_t *)initList;
	uint8_t cmd, x, numArgs;

	while ((cmd = pgm_read_byte(addr++)) > 0) { // '0' command ends list
		x = pgm_read_byte(addr++);
		numArgs = x & 0x7F;
		if (cmd != 0xFF) { // '255' is ignored
			SSD1351_sendCommand(cmd, addr, numArgs);
		}
		addr += numArgs;
	}
	
	SSD1351_setRotation(0);
		
	// STARTUP SCREEN
	SSD1351_fillScreen(SSD1351_BLACK);
	delay_ms(250);
}
/*!
    @brief   Set origin of (0,0) and orientation of OLED display
    @param   r
             The index for rotation, from 0 (0 deg) - 3 (270 deg) inclusive
    @return  None (void).
    @note    SSD1351 works differently than most (all?) other SPITFT
             displays. With certain rotation changes the screen contents
             may change immediately into a peculiar format (mirrored, not
             necessarily rotated) (other displays, this only affects new
             drawing -- rotation combinations can apply to different
             areas). Therefore, it's recommend to clear the screen
             (fillScreen(0)) before changing rotation.
*/
void SSD1351_setRotation(uint8_t r) {
  // madctl bits:
  // 6,7 Color depth (01 = 64K)
  // 5   Odd/even split COM (0: disable, 1: enable)
  // 4   Scan direction (0: top-down, 1: bottom-up)
  // 3   Reserved
  // 2   Color remap (0: A->B->C, 1: C->B->A)
  // 1   Column remap (0: 0-127, 1: 127-0)
  // 0   Address increment (0: horizontal, 1: vertical)
  uint8_t madctl = 0b01100100; // 64K, enable split, CBA

  rotation = r & 3; // Clip input to valid range

  switch (rotation) {
	  case 0:
	  madctl |= 0b00010000; // Scan bottom-up
	  break;
	  case 1:
	  madctl |= 0b00010011; // Scan bottom-up, column remap 127-0, vertical
	  break;
	  case 2:
	  madctl |= 0b00000010; // Column remap 127-0
	  break;
	  case 3:
	  madctl |= 0b00000001; // Vertical
	  break;
  }

  SSD1351_sendCommand(SSD1351_CMD_SETREMAP, &madctl, 1);
  uint8_t startline = (rotation < 2) ? SSD1351_HEIGHT : 0;
  SSD1351_sendCommand(SSD1351_CMD_STARTLINE, &startline, 1);
}

/*!
    @brief   Enable/Disable display color inversion
    @param   i
             True to invert display, False for normal color.
    @return  None (void).
    @note    This syntax is used by other SPITFT compatible libraries.
             New code should use this.
*/
void SSD1351_invertDisplay(bool i) {
	SPI_CS_LOW();
	SSD1351_write_command(i ? SSD1351_CMD_INVERTDISPLAY : SSD1351_CMD_NORMALDISPLAY);
	SPI_CS_HIGH();
}

#define SSD1351_swap(a, b)                                                     \
  (((a) ^= (b)), ((b) ^= (a)), ((a) ^= (b))) ///< No-temp-var swap operation

/*!
    @brief   Set the "address window" - the rectangle we will write to
             graphics RAM with the next chunk of SPI data writes. The
             SSD1351 will automatically wrap the data as each row is filled.
			 CS should be LOW before calling this function
    @param   x1
             Leftmost column of rectangle (screen pixel coordinates).
    @param   y1
             Topmost row of rectangle (screen pixel coordinates).
    @param   w
             Width of rectangle.
    @param   h
             Height of rectangle.
    @return  None (void).
*/
void SSD1351_setAddrWindow(uint16_t x1, uint16_t y1, uint16_t w,
                                     uint16_t h) {

  uint16_t x2 = x1 + w - 1, y2 = y1 + h - 1;
  uint8_t tmp[2];
  
  if (rotation & 1) { // Vertical address increment mode
    SSD1351_swap(x1, y1);
    SSD1351_swap(x2, y2);
  }
  
  SSD1351_write_command(SSD1351_CMD_SETCOLUMN); // X range
  tmp[0] = x1;
  tmp[1] = x2;
  io_write(io, tmp, 2);
  //tmp = x2;
  //io_write(io, &tmp, 1);
  SSD1351_write_command(SSD1351_CMD_SETROW); // Y range
  
  tmp[0] = y1;
  tmp[1] = y2;
  io_write(io, tmp, 2);
  //tmp = y2;
  //io_write(io, &tmp, 1);
  SSD1351_write_command(SSD1351_CMD_WRITERAM); // Begin write
}

/**************************************************************************/
/*!
 @brief  Change whether display is on or off
 @param   enable True if you want the display ON, false OFF
 */
/**************************************************************************/
void SSD1351_enableDisplay(bool enable) {
	SPI_CS_LOW();
	SSD1351_write_command(enable ? SSD1351_CMD_DISPLAYON : SSD1351_CMD_DISPLAYOFF);
  	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
   @brief    Write a line.  Bresenham's algorithm - thx wikpedia
    @param    x0  Start point x coordinate
    @param    y0  Start point y coordinate
    @param    x1  End point x coordinate
    @param    y1  End point y coordinate
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void SSD1351_writeLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                             uint16_t color) 
{

  int16_t steep = abs(y1 - y0) > abs(x1 - x0);
  if (steep) {
    _swap_int16_t(x0, y0);
    _swap_int16_t(x1, y1);
  }

  if (x0 > x1) {
    _swap_int16_t(x0, x1);
    _swap_int16_t(y0, y1);
  }

  int16_t dx, dy;
  dx = x1 - x0;
  dy = abs(y1 - y0);

  int16_t err = dx / 2;
  int16_t ystep;

  if (y0 < y1) {
    ystep = 1;
  } else {
    ystep = -1;
  }

  for (; x0 <= x1; x0++) {
    if (steep) {
      SSD1351_writePixel(y0, x0, color);
    } else {
      SSD1351_writePixel(x0, y0, color);
    }
    err -= dy;
    if (err < 0) {
      y0 += ystep;
      err += dx;
    }
  }
}

/**************************************************************************/
/*!
    @brief  Draw a single pixel to the display at requested coordinates.
    Not self-contained; should follow a SPI_CS_LOW() call.
    @param  x      Horizontal position (0 = left).
    @param  y      Vertical position   (0 = top).
    @param  color  16-bit pixel color in '565' RGB format.
   
*/
/**************************************************************************/
void SSD1351_writePixel(int16_t x, int16_t y, uint16_t color) {
  SSD1351_drawPixel(x, y, color);
}

/**************************************************************************/
/*!
   @brief    Write a perfectly vertical line, overwrite in subclasses if
   SPI_CS_LOW is defined!
    @param    x   Top-most x coordinate
    @param    y   Top-most y coordinate
    @param    h   Height in pixels
   @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_writeFastVLine(int16_t x, int16_t y, int16_t h,
                                  uint16_t color) 
{
  // Overwrite in subclasses if SPI_CS_LOW is defined!
  // Can be just writeLine(x, y, x, y+h-1, color);
  // or writeFillRect(x, y, 1, h, color);
  SSD1351_drawFastVLine(x, y, h, color);
}

/**************************************************************************/
/*!
   @brief    Write a perfectly horizontal line, overwrite in subclasses if
   SPI_CS_LOW is defined!
    @param    x   Left-most x coordinate
    @param    y   Left-most y coordinate
    @param    w   Width in pixels
   @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_writeFastHLine(int16_t x, int16_t y, int16_t w,
                                  uint16_t color) 
{
  // Overwrite in subclasses if SPI_CS_LOW is defined!
  // Example: writeLine(x, y, x+w-1, y, color);
  // or writeFillRect(x, y, w, 1, color);
  SSD1351_drawFastHLine(x, y, w, color);
}

/**************************************************************************/
/*!
   @brief    Write a rectangle completely with one color, overwrite in
   subclasses if SPI_CS_LOW is defined!
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    w   Width in pixels
    @param    h   Height in pixels
   @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_writeFillRect(int16_t x, int16_t y, int16_t w, int16_t h,
                                 uint16_t color) 
{
  // Overwrite in subclasses if desired!
  SSD1351_fillRect(x, y, w, h, color);
}


/**************************************************************************/
/*!
   @brief    Draw a perfectly vertical line (this is often optimized in a
   subclass!)
    @param    x   Top-most x coordinate
    @param    y   Top-most y coordinate
    @param    h   Height in pixels
   @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_drawFastVLine(int16_t x, int16_t y, int16_t h,
                                 uint16_t color) 
{
	SPI_CS_LOW();
	SSD1351_writeLine(x, y, x, y + h - 1, color);
	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
   @brief    Draw a perfectly horizontal line (this is often optimized in a
   subclass!)
    @param    x   Left-most x coordinate
    @param    y   Left-most y coordinate
    @param    w   Width in pixels
   @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_drawFastHLine(int16_t x, int16_t y, int16_t w,
                                 uint16_t color) 
{
	SPI_CS_LOW();									 
	SSD1351_writeLine(x, y, x + w - 1, y, color);
	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
   @brief    Fill a rectangle completely with one color. Update in subclasses if
   desired!
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    w   Width in pixels
    @param    h   Height in pixels
   @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_fillRect(int16_t x, int16_t y, int16_t w, int16_t h,
                            uint16_t color) 
{
	SPI_CS_LOW();							
	for (int16_t i = x; i < x + w; i++) {
		SSD1351_writeFastVLine(i, y, h, color);
	}
	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
   @brief    Fill the screen completely with one color. Faster clear screen now
    @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_fillScreen(uint16_t color) 
{
	//SSD1351_fillRect(0, 0, SSD1351_WIDTH, SSD1351_HEIGHT, color);	// slower
	
	uint8_t tmp;
	
	SPI_CS_LOW();
	
	SSD1351_setAddrWindow(0, 0, SSD1351_WIDTH, SSD1351_HEIGHT);
	
	for (int32_t i = 0; i < SSD1351_WIDTH*SSD1351_HEIGHT; i++) {
		tmp = color>>8;
		io_write(io, &tmp, 1);
		tmp = color;
		io_write(io, &tmp, 1);
		
		//spi_write16(color);
	}
	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
   @brief    Draw a line
    @param    x0  Start point x coordinate
    @param    y0  Start point y coordinate
    @param    x1  End point x coordinate
    @param    y1  End point y coordinate
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void SSD1351_drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                            uint16_t color) 
{
  // Update in subclasses if desired!
  if (x0 == x1) {
    if (y0 > y1)
      _swap_int16_t(y0, y1);
    SSD1351_drawFastVLine(x0, y0, y1 - y0 + 1, color);
  } else if (y0 == y1) {
    if (x0 > x1)
      _swap_int16_t(x0, x1);
    SSD1351_drawFastHLine(x0, y0, x1 - x0 + 1, color);
  } else {
	SPI_CS_LOW();
    SSD1351_writeLine(x0, y0, x1, y1, color);
	SPI_CS_HIGH();
  }
}

/**************************************************************************/
/*!
   @brief    Draw a circle outline
    @param    x0   Center-point x coordinate
    @param    y0   Center-point y coordinate
    @param    r   Radius of circle
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void SSD1351_drawCircle(int16_t x0, int16_t y0, int16_t r,
                              uint16_t color) 
{

  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;

	SPI_CS_LOW();
  SSD1351_writePixel(x0, y0 + r, color);
  SSD1351_writePixel(x0, y0 - r, color);
  SSD1351_writePixel(x0 + r, y0, color);
  SSD1351_writePixel(x0 - r, y0, color);

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    SSD1351_writePixel(x0 + x, y0 + y, color);
    SSD1351_writePixel(x0 - x, y0 + y, color);
    SSD1351_writePixel(x0 + x, y0 - y, color);
    SSD1351_writePixel(x0 - x, y0 - y, color);
    SSD1351_writePixel(x0 + y, y0 + x, color);
    SSD1351_writePixel(x0 - y, y0 + x, color);
    SSD1351_writePixel(x0 + y, y0 - x, color);
    SSD1351_writePixel(x0 - y, y0 - x, color);
  }
  SPI_CS_HIGH();
}

/**************************************************************************/
/*!
    @brief    Quarter-circle drawer, used to do circles and roundrects
    @param    x0   Center-point x coordinate
    @param    y0   Center-point y coordinate
    @param    r   Radius of circle
    @param    cornername  Mask bit #1 or bit #2 to indicate which quarters of
   the circle we're doing
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void SSD1351_drawCircleHelper(int16_t x0, int16_t y0, int16_t r,
                                    uint8_t cornername, uint16_t color) 
{
  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;
    if (cornername & 0x4) {
      SSD1351_writePixel(x0 + x, y0 + y, color);
      SSD1351_writePixel(x0 + y, y0 + x, color);
    }
    if (cornername & 0x2) {
      SSD1351_writePixel(x0 + x, y0 - y, color);
      SSD1351_writePixel(x0 + y, y0 - x, color);
    }
    if (cornername & 0x8) {
      SSD1351_writePixel(x0 - y, y0 + x, color);
      SSD1351_writePixel(x0 - x, y0 + y, color);
    }
    if (cornername & 0x1) {
      SSD1351_writePixel(x0 - y, y0 - x, color);
      SSD1351_writePixel(x0 - x, y0 - y, color);
    }
  }
}

/**************************************************************************/
/*!
   @brief    Draw a circle with filled color
    @param    x0   Center-point x coordinate
    @param    y0   Center-point y coordinate
    @param    r   Radius of circle
    @param    color 16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_fillCircle(int16_t x0, int16_t y0, int16_t r,
                              uint16_t color) 
{
	SPI_CS_LOW();		  
	SSD1351_writeFastVLine(x0, y0 - r, 2 * r + 1, color);
	SSD1351_fillCircleHelper(x0, y0, r, 3, 0, color);
	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
    @brief  Quarter-circle drawer with fill, used for circles and roundrects
    @param  x0       Center-point x coordinate
    @param  y0       Center-point y coordinate
    @param  r        Radius of circle
    @param  corners  Mask bits indicating which quarters we're doing
    @param  delta    Offset from center-point, used for round-rects
    @param  color    16-bit 5-6-5 Color to fill with
*/
/**************************************************************************/
void SSD1351_fillCircleHelper(int16_t x0, int16_t y0, int16_t r,
                                    uint8_t corners, int16_t delta,
                                    uint16_t color) 
{

  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;
  int16_t px = x;
  int16_t py = y;

  delta++; // Avoid some +1's in the loop

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;
    // These checks avoid double-drawing certain lines, important
    // for the SSD1306 library which has an INVERT drawing mode.
    if (x < (y + 1)) {
      if (corners & 1)
        SSD1351_writeFastVLine(x0 + x, y0 - y, 2 * y + delta, color);
      if (corners & 2)
        SSD1351_writeFastVLine(x0 - x, y0 - y, 2 * y + delta, color);
    }
    if (y != py) {
      if (corners & 1)
        SSD1351_writeFastVLine(x0 + py, y0 - px, 2 * px + delta, color);
      if (corners & 2)
        SSD1351_writeFastVLine(x0 - py, y0 - px, 2 * px + delta, color);
      py = y;
    }
    px = x;
  }
}

/**************************************************************************/
/*!
   @brief   Draw a rectangle with no fill color
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    w   Width in pixels
    @param    h   Height in pixels
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void SSD1351_drawRect(int16_t x, int16_t y, int16_t w, int16_t h,
                            uint16_t color) 
{
	SPI_CS_LOW();
	SSD1351_writeFastHLine(x, y, w, color);
	SSD1351_writeFastHLine(x, y + h - 1, w, color);
	SSD1351_writeFastVLine(x, y, h, color);
	SSD1351_writeFastVLine(x + w - 1, y, h, color);
	SPI_CS_HIGH();

}

/**************************************************************************/
/*!
   @brief   Draw a rounded rectangle with no fill color
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    w   Width in pixels
    @param    h   Height in pixels
    @param    r   Radius of corner rounding
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void SSD1351_drawRoundRect(int16_t x, int16_t y, int16_t w, int16_t h,
                                 int16_t r, uint16_t color) 
{
  int16_t max_radius = ((w < h) ? w : h) / 2; // 1/2 minor axis
  if (r > max_radius)
    r = max_radius;
  // smarter version
	SPI_CS_LOW();
	SSD1351_writeFastHLine(x + r, y, w - 2 * r, color);         // Top
	SSD1351_writeFastHLine(x + r, y + h - 1, w - 2 * r, color); // Bottom
	SSD1351_writeFastVLine(x, y + r, h - 2 * r, color);         // Left
	SSD1351_writeFastVLine(x + w - 1, y + r, h - 2 * r, color); // Right
	// draw four corners
	SSD1351_drawCircleHelper(x + r, y + r, r, 1, color);
	SSD1351_drawCircleHelper(x + w - r - 1, y + r, r, 2, color);
	SSD1351_drawCircleHelper(x + w - r - 1, y + h - r - 1, r, 4, color);
	SSD1351_drawCircleHelper(x + r, y + h - r - 1, r, 8, color);
	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
   @brief   Draw a rounded rectangle with fill color
    @param    x   Top left corner x coordinate
    @param    y   Top left corner y coordinate
    @param    w   Width in pixels
    @param    h   Height in pixels
    @param    r   Radius of corner rounding
    @param    color 16-bit 5-6-5 Color to draw/fill with
*/
/**************************************************************************/
void SSD1351_fillRoundRect(int16_t x, int16_t y, int16_t w, int16_t h,
                                 int16_t r, uint16_t color) 
{
  int16_t max_radius = ((w < h) ? w : h) / 2; // 1/2 minor axis
  if (r > max_radius)
    r = max_radius;
  // smarter version
	SPI_CS_LOW();
	SSD1351_writeFillRect(x + r, y, w - 2 * r, h, color);
	// draw four corners
	SSD1351_fillCircleHelper(x + w - r - 1, y + r, r, 1, h - 2 * r - 1, color);
	SSD1351_fillCircleHelper(x + r, y + r, r, 2, h - 2 * r - 1, color);
	SPI_CS_HIGH();
}

/**************************************************************************/
/*!
   @brief   Draw a triangle with no fill color
    @param    x0  Vertex #0 x coordinate
    @param    y0  Vertex #0 y coordinate
    @param    x1  Vertex #1 x coordinate
    @param    y1  Vertex #1 y coordinate
    @param    x2  Vertex #2 x coordinate
    @param    y2  Vertex #2 y coordinate
    @param    color 16-bit 5-6-5 Color to draw with
*/
/**************************************************************************/
void SSD1351_drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                                int16_t x2, int16_t y2, uint16_t color) 
{
  SSD1351_drawLine(x0, y0, x1, y1, color);
  SSD1351_drawLine(x1, y1, x2, y2, color);
  SSD1351_drawLine(x2, y2, x0, y0, color);
}

/**************************************************************************/
/*!
   @brief     Draw a triangle with color-fill
    @param    x0  Vertex #0 x coordinate
    @param    y0  Vertex #0 y coordinate
    @param    x1  Vertex #1 x coordinate
    @param    y1  Vertex #1 y coordinate
    @param    x2  Vertex #2 x coordinate
    @param    y2  Vertex #2 y coordinate
    @param    color 16-bit 5-6-5 Color to fill/draw with
*/
/**************************************************************************/
void SSD1351_fillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                                int16_t x2, int16_t y2, uint16_t color) 
{

  int16_t a, b, y, last;

  // Sort coordinates by Y order (y2 >= y1 >= y0)
  if (y0 > y1) {
    _swap_int16_t(y0, y1);
    _swap_int16_t(x0, x1);
  }
  if (y1 > y2) {
    _swap_int16_t(y2, y1);
    _swap_int16_t(x2, x1);
  }
  if (y0 > y1) {
    _swap_int16_t(y0, y1);
    _swap_int16_t(x0, x1);
  }

  SPI_CS_LOW();
  if (y0 == y2) { // Handle awkward all-on-same-line case as its own thing
    a = b = x0;
    if (x1 < a)
      a = x1;
    else if (x1 > b)
      b = x1;
    if (x2 < a)
      a = x2;
    else if (x2 > b)
      b = x2;
    SSD1351_writeFastHLine(a, y0, b - a + 1, color);
    SPI_CS_HIGH();
    return;
  }

  int16_t dx01 = x1 - x0, dy01 = y1 - y0, dx02 = x2 - x0, dy02 = y2 - y0,
          dx12 = x2 - x1, dy12 = y2 - y1;
  int32_t sa = 0, sb = 0;

  // For upper part of triangle, find scanline crossings for segments
  // 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
  // is included here (and second loop will be skipped, avoiding a /0
  // error there), otherwise scanline y1 is skipped here and handled
  // in the second loop...which also avoids a /0 error here if y0=y1
  // (flat-topped triangle).
  if (y1 == y2)
    last = y1; // Include y1 scanline
  else
    last = y1 - 1; // Skip it

  for (y = y0; y <= last; y++) {
    a = x0 + sa / dy01;
    b = x0 + sb / dy02;
    sa += dx01;
    sb += dx02;
    /* longhand:
    a = x0 + (x1 - x0) * (y - y0) / (y1 - y0);
    b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
    */
    if (a > b)
      _swap_int16_t(a, b);
    SSD1351_writeFastHLine(a, y, b - a + 1, color);
  }

  // For lower part of triangle, find scanline crossings for segments
  // 0-2 and 1-2.  This loop is skipped if y1=y2.
  sa = (int32_t)dx12 * (y - y1);
  sb = (int32_t)dx02 * (y - y0);
  for (; y <= y2; y++) {
    a = x1 + sa / dy12;
    b = x0 + sb / dy02;
    sa += dx12;
    sb += dx02;
    /* longhand:
    a = x1 + (x2 - x1) * (y - y1) / (y2 - y1);
    b = x0 + (x2 - x0) * (y - y0) / (y2 - y0);
    */
    if (a > b)
      _swap_int16_t(a, b);
    SSD1351_writeFastHLine(a, y, b - a + 1, color);
  }
  //SPI_CS_HIGH();
}

// TEXT- AND CHARACTER-HANDLING FUNCTIONS ----------------------------------

// Draw a character
/**************************************************************************/
/*!
   @brief   Draw a single character
    @param    x   Bottom left corner x coordinate
    @param    y   Bottom left corner y coordinate
    @param    c   The 8-bit font-indexed character (likely ascii)
    @param    color 16-bit 5-6-5 Color to draw chraracter with
    @param    bg 16-bit 5-6-5 Color to fill background with (if same as color,
   no background)
    @param    size_x  Font magnification level in X-axis, 1 is 'original' size
    @param    size_y  Font magnification level in Y-axis, 1 is 'original' size
*/
/**************************************************************************/
void SSD1351_drawChar(int16_t x, int16_t y, unsigned char c,
                            uint16_t color, uint16_t bg, uint8_t size_x,
                            uint8_t size_y) 
{

    if ((x >= SSD1351_WIDTH) ||              // Clip right
        (y >= SSD1351_HEIGHT) ||             // Clip bottom
        ((x + 6 * size_x - 1) < 0) || // Clip left
        ((y + 8 * size_y - 1) < 0))   // Clip top
      return;

    SPI_CS_LOW();
    for (int8_t i = 0; i < 5; i++) { // Char bitmap = 5 columns
      uint8_t line = pgm_read_byte(&font[c * 5 + i]);
      for (int8_t j = 0; j < 8; j++, line >>= 1) {
        if (line & 1) {
          if (size_x == 1 && size_y == 1)
            SSD1351_writePixel(x + i, y + j, color);
          else
            SSD1351_writeFillRect(x + i * size_x, y + j * size_y, size_x, size_y,
                          color);
        } else if (bg != color) {
          if (size_x == 1 && size_y == 1)
            SSD1351_writePixel(x + i, y + j, bg);
          else
            SSD1351_writeFillRect(x + i * size_x, y + j * size_y, size_x, size_y, bg);
        }
      }
    }
    if (bg != color) { // If opaque, draw vertical line for last column
      if (size_x == 1 && size_y == 1)
        SSD1351_writeFastVLine(x + 5, y, 8, bg);
      else
        SSD1351_writeFillRect(x + 5 * size_x, y, size_x, 8 * size_y, bg);
    }
    SPI_CS_HIGH();

}
/**************************************************************************/
/*!
    @brief  Print one byte/character of data
    @param  c  The 8-bit ascii character to write
*/
/**************************************************************************/
size_t SSD1351_write(uint8_t c) {

    if (c == '\n') {              // Newline?
      cursor_x = 0;               // Reset x to zero,
      cursor_y += textsize_y * 8; // advance y one line
    } else if (c != '\r') {       // Ignore carriage returns
      if (((cursor_x + textsize_x * 6) > SSD1351_WIDTH)) { // Off right?, 'wrap' text at right edge of display 
        cursor_x = 0;                                       // Reset x to zero,
        cursor_y += textsize_y * 8; // advance y one line
      }
      SSD1351_drawChar(cursor_x, cursor_y, c, textcolor, textbgcolor, textsize_x,
               textsize_y);
      cursor_x += textsize_x * 6; // Advance x one char
    }

  return 1;
}


/**************************************************************************/
/*!
    @brief  print string
    @param  
*/
/**************************************************************************/
size_t SSD1351_writestr(const char *str)
{
	size_t n = 0;
	size_t size = strlen(str);
	
	while (size--) {
		if (SSD1351_write(*str++)) 
			n++;
		else 
			break;
	}
	return n;
}

/**************************************************************************/
/*!
    @brief   Set text 'magnification' size. Each increase in s makes 1 pixel
   that much bigger.
    @param  s_x  Desired text width magnification level in X-axis. 1 is default 6x8, 2 is 12x16, 3 is 18x24, etc
    @param  s_y  Desired text width magnification level in Y-axis. 1 is default
*/
/**************************************************************************/
void SSD1351_setTextSize(uint8_t s_x, uint8_t s_y) {
  textsize_x = (s_x > 0) ? s_x : 1;
  textsize_y = (s_y > 0) ? s_y : 1;
}


/*!
    @brief  Swap bytes in an array of pixels; converts little-to-big or
            big-to-little endian. Used by writePixels() below in some
            situations, but may also be helpful for user code occasionally.
    @param  src   Source address of 16-bit pixels buffer.
    @param  len   Number of pixels to byte-swap.
    @param  dest  Optional destination address if different than src --
                  otherwise, if NULL (default) or same address is passed,
                  pixel buffer is overwritten in-place.
*/
void SSD1351_swapBytes(uint16_t *src, uint32_t len, uint16_t *dest) {
  if (!dest)
    dest = src; // NULL -> overwrite src buffer
  for (uint32_t i = 0; i < len; i++) {
    dest[i] = __builtin_bswap16(src[i]);
  }
}

/*!
    @brief  Issue a series of pixels from memory to the display. Not self-
            contained; should follow SPI_CS_LOW() and setAddrWindow() calls.
    @param  colors     Pointer to array of 16-bit pixel values in '565' RGB
                       format.
    @param  len        Number of elements in 'colors' array.
    @param  block      If true (default case if unspecified), function blocks
                       until DMA transfer is complete. This is simply IGNORED
                       if DMA is not enabled. If false, the function returns
                       immediately after the last DMA transfer is started,
                       and one should use the dmaWait() function before
                       doing ANY other display-related activities (or even
                       any SPI-related activities, if using an SPI display
                       that shares the bus with other devices).
    @param  bigEndian  If true, bitmap in memory is in big-endian order (most
                       significant byte first). By default this is false, as
                       most microcontrollers seem to be little-endian and
                       16-bit pixel values must be byte-swapped before
                       issuing to the display (which tend toward big-endian
                       when using SPI or 8-bit parallel). If an application
                       can optimize around this -- for example, a bitmap in a
                       uint16_t array having the byte values already ordered
                       big-endian, this can save time here, ESPECIALLY if
                       using this function's non-blocking DMA mode.
*/
void SSD1351_writePixels(uint16_t *colors, uint32_t len, bool block,
                                  bool bigEndian) {

  if (!len)
    return; // Avoid 0-byte transfers

  // avoid paramater-not-used complaints
  (void)block;
  (void)bigEndian;
  uint8_t tmp;
	
  if (!bigEndian) {
	  while (len--) {
		tmp = (*colors)>>8;
		io_write(io, &tmp, 1);
		tmp = *colors;
		io_write(io, &tmp, 1);
		*colors = *colors + 1;
		  //spi_write16(*colors++);
	  }
	  } else {
	  while (len--) {
		  uint16_t tst = __builtin_bswap16(*colors);
			tmp = tst>>8;
			io_write(io, &tmp, 1);
			tmp = tst;
			io_write(io, &tmp, 1);
			*colors = *colors + 1;;
		  //spi_write16(__builtin_bswap16(*colors++));
	  }
  }
}


/*!
    @brief  Issue a series of pixels, all the same color. Not self-
            contained; should follow SPI_CS_LOW() and setAddrWindow() calls.
    @param  color  16-bit pixel color in '565' RGB format.
    @param  len    Number of pixels to draw.
*/
void SSD1351_writeColor(uint16_t color, uint32_t len) {

  if (!len)
  {
    return; // Avoid 0-byte transfers
  }
  
  uint8_t tmp;
	while (len--) {
		tmp = color>>8;
		io_write(io, &tmp, 1);
		tmp = color;
		io_write(io, &tmp, 1);
		//spi_write16(color);
	}
}



/*!
    @brief  A lower-level version of writeFillRect(). This version requires
            all inputs are in-bounds, that width and height are positive,
            and no part extends offscreen. NO EDGE CLIPPING OR REJECTION IS
            PERFORMED. If higher-level graphics primitives are written to
            handle their own clipping earlier in the drawing process, this
            can avoid unnecessary function calls and repeated clipping
            operations in the lower-level functions. It should follow SPI_CS_LOW()
    @param  x      Horizontal position of first corner. MUST BE WITHIN
                   SCREEN BOUNDS.
    @param  y      Vertical position of first corner. MUST BE WITHIN SCREEN
                   BOUNDS.
    @param  w      Rectangle width in pixels. MUST BE POSITIVE AND NOT
                   EXTEND OFF SCREEN.
    @param  h      Rectangle height in pixels. MUST BE POSITIVE AND NOT
                   EXTEND OFF SCREEN.
    @param  color  16-bit fill color in '565' RGB format.
    @note   This is a new function, no graphics primitives besides rects
            and horizontal/vertical lines are written to best use this yet.
*/
inline void SSD1351_writeFillRectPreclipped(int16_t x, int16_t y,
                                                     int16_t w, int16_t h,
                                                     uint16_t color) {
  SSD1351_setAddrWindow(x, y, w, h);
  SSD1351_writeColor(color, (uint32_t)w * h);
}

/*!
    @brief  Draw a single pixel to the display at requested coordinates.
            Self-contained and provides its own transaction as needed
            (see writePixel(x,y,color) for a lower-level variant).
            Edge clipping is performed here.
    @param  x      Horizontal position (0 = left).
    @param  y      Vertical position   (0 = top).
    @param  color  16-bit pixel color in '565' RGB format.
*/
void SSD1351_drawPixel(int16_t x, int16_t y, uint16_t color) {
  // Clip first...
  if ((x >= 0) && (x < SSD1351_WIDTH) && (y >= 0) && (y < SSD1351_HEIGHT)) {
	 uint8_t tmp;
    // THEN set up transaction (if needed) and draw...
    SPI_CS_LOW();
    SSD1351_setAddrWindow(x, y, 1, 1);
	
	tmp = color>>8;
	io_write(io, &tmp, 1);
	tmp = color;
	io_write(io, &tmp, 1);
	
    //spi_write16(color);
    SPI_CS_HIGH();
  }
}


/*!
    @brief  Draw a 16-bit image (565 RGB) at the specified (x,y) position.
            For 16-bit display devices; no color reduction performed.
            Adapted from https://github.com/PaulStoffregen/SSD1351_t3
            by Marc MERLIN. See examples/pictureEmbed to use this.
            5/6/2017: function name and arguments have changed for
            compatibility with current GFX library and to avoid naming
            problems in prior implementation.  Formerly drawBitmap() with
            arguments in different order. 
    @param  x        Top left corner horizontal coordinate.
    @param  y        Top left corner vertical coordinate.
    @param  pcolors  byte array with 16-bit color bitmap.
    @param  w        Width of bitmap in pixels.
    @param  h        Height of bitmap in pixels.
*/
void SSD1351_drawRGBBitmap(int16_t x, int16_t y, const uint16_t pcolors[],
                                    int16_t w, int16_t h) {

	int16_t x2, y2;                 // Lower-right coord
	if ((x >= SSD1351_WIDTH) ||            // Off-edge right
		(y >= SSD1351_HEIGHT) ||           // " top
		((x2 = (x + w - 1)) < 0) || // " left
		((y2 = (y + h - 1)) < 0))
		return; // " bottom

	int16_t bx1 = 0, by1 = 0, // Clipped top-left within bitmap
		saveW = w;            // Save original bitmap width value
		
	if (x < 0) {              // Clip left
		w += x;
		bx1 = -x;
		x = 0;
	}
	
	if (y < 0) { // Clip top
		h += y;
		by1 = -y;
		y = 0;
	}
	if (x2 >= SSD1351_WIDTH)
		w = SSD1351_WIDTH - x; // Clip right
		
	if (y2 >= SSD1351_HEIGHT)
		h = SSD1351_HEIGHT - y; // Clip bottom

	pcolors += by1 * saveW + bx1; // Offset bitmap ptr to clipped top-left
	
	SPI_CS_LOW();
	
	SSD1351_setAddrWindow(x, y, w, h); // Clipped area
  
	for (int16_t j = 0; j < h; j++, y++) {
		for (int16_t i = 0; i < w; i++) {
			SSD1351_writePixel(x + i, y, pgm_read_word(&pcolors[j * w + i]));
		}
	}
	
	//while (h--) {              // For each (clipped) scanline...
		//SSD1351_writePixels(pcolors, w, true, false); // Push one (clipped) row
		//pcolors += saveW;        // Advance pointer by one full (unclipped) line
	//}
  
	SPI_CS_HIGH();
}

// -------------------------------------------------------------------------
// Miscellaneous class member functions that don't draw anything.

/*!
    @brief   Given 8-bit red, green and blue values, return a 'packed'
             16-bit color value in '565' RGB format (5 bits red, 6 bits
             green, 5 bits blue). This is just a mathematical operation,
             no hardware is touched.
    @param   red    8-bit red brightness (0 = off, 255 = max).
    @param   green  8-bit green brightness (0 = off, 255 = max).
    @param   blue   8-bit blue brightness (0 = off, 255 = max).
    @return  'Packed' 16-bit color value (565 format).
*/
uint16_t SSD1351_color565(uint8_t red, uint8_t green, uint8_t blue) {
  return ((red & 0xF8) << 8) | ((green & 0xFC) << 3) | (blue >> 3);
}

  /**********************************************************************/
  /*!
    @brief  Set text cursor location
    @param  x    X coordinate in pixels
    @param  y    Y coordinate in pixels
  */
  /**********************************************************************/
  void SSD1351_setCursor(int16_t x, int16_t y) {
    cursor_x = x;
    cursor_y = y;
  }
  
    /**********************************************************************/
  /*!
    @brief   Set text font color with transparent background
    @param   c   16-bit 5-6-5 Color to draw text with
    @note    For 'transparent' background, background and foreground
             are set to same color rather than using a separate flag.
  */
  /**********************************************************************/
  void SSD1351_setTextColor(uint16_t c) { 
	  textcolor = textbgcolor = c; 
  }

