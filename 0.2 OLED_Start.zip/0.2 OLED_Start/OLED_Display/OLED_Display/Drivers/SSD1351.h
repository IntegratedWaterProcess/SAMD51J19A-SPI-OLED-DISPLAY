#ifndef SSD1351_H_
#define SSD1351_H_

#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>
#include <hpl_gclk_base.h>
#include <hpl_pm_base.h>
//#include <hal_spi_m_sync.h>
#include <hal_delay.h>
#include <string.h>

#include "gpio_pins.h"
#include "OLED_Display/Graphics/glcdfont.h"

#ifndef min
#define min(a, b) (((a) < (b)) ? (a) : (b))
#endif

#ifndef _swap_int16_t
#define _swap_int16_t(a, b) { int16_t t = a; 	a = b; 	b = t; }
#endif

#define pgm_read_byte(addr) (*(const unsigned char *)(addr))
#define pgm_read_word(addr) (*(const unsigned short *)(addr))

extern struct spi_m_sync_descriptor OLED_SPI;

#define SSD1351_WIDTH 128  
#define SSD1351_HEIGHT 128 


#define SSD1351_CMD_SETCOLUMN 0x15      ///< See datasheet
#define SSD1351_CMD_SETROW 0x75         ///< See datasheet
#define SSD1351_CMD_WRITERAM 0x5C       ///< See datasheet
#define SSD1351_CMD_READRAM 0x5D        ///< Not currently used
#define SSD1351_CMD_SETREMAP 0xA0       ///< See datasheet
#define SSD1351_CMD_STARTLINE 0xA1      ///< See datasheet
#define SSD1351_CMD_DISPLAYOFFSET 0xA2  ///< See datasheet
#define SSD1351_CMD_DISPLAYALLOFF 0xA4  ///< Not currently used
#define SSD1351_CMD_DISPLAYALLON 0xA5   ///< Not currently used
#define SSD1351_CMD_NORMALDISPLAY 0xA6  ///< See datasheet
#define SSD1351_CMD_INVERTDISPLAY 0xA7  ///< See datasheet
#define SSD1351_CMD_FUNCTIONSELECT 0xAB ///< See datasheet
#define SSD1351_CMD_DISPLAYOFF 0xAE     ///< See datasheet
#define SSD1351_CMD_DISPLAYON 0xAF      ///< See datasheet
#define SSD1351_CMD_PRECHARGE 0xB1      ///< See datasheet
#define SSD1351_CMD_DISPLAYENHANCE 0xB2 ///< Not currently used
#define SSD1351_CMD_CLOCKDIV 0xB3       ///< See datasheet		179
#define SSD1351_CMD_SETVSL 0xB4         ///< See datasheet
#define SSD1351_CMD_SETGPIO 0xB5        ///< See datasheet
#define SSD1351_CMD_PRECHARGE2 0xB6     ///< See datasheet
#define SSD1351_CMD_SETGRAY 0xB8        ///< Not currently used
#define SSD1351_CMD_USELUT 0xB9         ///< Not currently used
#define SSD1351_CMD_PRECHARGELEVEL 0xBB ///< Not currently used
#define SSD1351_CMD_VCOMH 0xBE          ///< See datasheet
#define SSD1351_CMD_CONTRASTABC 0xC1    ///< See datasheet
#define SSD1351_CMD_CONTRASTMASTER 0xC7 ///< See datasheet
#define SSD1351_CMD_MUXRATIO 0xCA       ///< See datasheet
#define SSD1351_CMD_COMMANDLOCK 0xFD    ///< See datasheet
#define SSD1351_CMD_HORIZSCROLL 0x96    ///< Not currently used
#define SSD1351_CMD_STOPSCROLL 0x9E     ///< Not currently used
#define SSD1351_CMD_STARTSCROLL 0x9F    ///< Not currently used

// Color definitions
#define SSD1351_BLACK 0x0000       ///<   0,   0,   0
#define SSD1351_NAVY 0x000F        ///<   0,   0, 123
#define SSD1351_DARKGREEN 0x03E0   ///<   0, 125,   0
#define SSD1351_DARKCYAN 0x03EF    ///<   0, 125, 123
#define SSD1351_MAROON 0x7800      ///< 123,   0,   0
#define SSD1351_PURPLE 0x780F      ///< 123,   0, 123
#define SSD1351_OLIVE 0x7BE0       ///< 123, 125,   0
#define SSD1351_LIGHTGREY 0xC618   ///< 198, 195, 198
#define SSD1351_DARKGREY 0x7BEF    ///< 123, 125, 123
#define SSD1351_BLUE 0x001F        ///<   0,   0, 255
#define SSD1351_GREEN 0x07E0       ///<   0, 255,   0
#define SSD1351_CYAN 0x07FF        ///<   0, 255, 255
#define SSD1351_RED 0xF800         ///< 255,   0,   0
#define SSD1351_MAGENTA 0xF81F     ///< 255,   0, 255
#define SSD1351_YELLOW 0xFFE0      ///< 255, 255,   0
#define SSD1351_WHITE 0xFFFF       ///< 255, 255, 255
#define SSD1351_ORANGE 0xFD20      ///< 255, 165,   0
#define SSD1351_GREENYELLOW 0xAFE5 ///< 173, 255,  41
#define SSD1351_PINK 0xFC18        ///< 255, 130, 198

#define SSD1351_WATER 0x24BE	   ///< 61 , 154, 226

void OLED_SPI_init(void);
void SSD1351_init(void);
void SSD1351_setRotation(uint8_t r);
void SSD1351_invertDisplay(bool i); // Preferred syntax (same as other screens)
void SSD1351_enableDisplay(bool enable);
void SSD1351_setAddrWindow(uint16_t x, uint16_t y, uint16_t w, uint16_t h);
void SSD1351_setTextSize(uint8_t sx, uint8_t sy);
void SSD1351_setTextColor(uint16_t c);

void SPI_DC_LOW();
void SPI_DC_HIGH();

void SPI_CS_LOW();
void SPI_CS_HIGH();

void SSD1351_write_command(const uint8_t command);
void SSD1351_write_data(const uint8_t data);
void SSD1351_hard_reset(void);


  /*!
      @brief  Set up the specific display hardware's "address window"
              for subsequent pixel-pushing operations.
      @param  x  Leftmost pixel of area to be drawn (MUST be within
                 display bounds at current rotation setting).
      @param  y  Topmost pixel of area to be drawn (MUST be within
                 display bounds at current rotation setting).
      @param  w  Width of area to be drawn, in pixels (MUST be >0 and,
                 added to x, within display bounds at current rotation).
      @param  h  Height of area to be drawn, in pixels (MUST be >0 and,
                 added to x, within display bounds at current rotation).
  */
void SSD1351_setAddrWindow(uint16_t x, uint16_t y, uint16_t w, uint16_t h);
  
  // These functions require a chip-select and/or SPI transaction
  // around them. Higher-level graphics primitives might start a
  // single transaction and then make multiple calls to these functions
  // (e.g. circle or text rendering might make repeated lines or rects)
  // before ending the transaction. It's more efficient than starting a
  // transaction every time.
  void SSD1351_writePixel(int16_t x, int16_t y, uint16_t color);
  void SSD1351_writePixels(uint16_t *colors, uint32_t len, bool block,
                   bool bigEndian);
  void SSD1351_writeColor(uint16_t color, uint32_t len);
  void SSD1351_writeFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color);
  void SSD1351_writeFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color);
  // This is a new function, similar to writeFillRect() except that
  // all arguments MUST be onscreen, sorted and clipped. If higher-level
  // primitives can handle their own sorting/clipping, it avoids repeating
  // such operations in the low-level code, making it potentially faster.
  // CALLING THIS WITH UNCLIPPED OR NEGATIVE VALUES COULD BE DISASTROUS.
  void SSD1351_writeFillRectPreclipped(int16_t x, int16_t y, int16_t w,
                                      int16_t h, uint16_t color);

  void SSD1351_swapBytes(uint16_t *src, uint32_t len, uint16_t *dest);

  void SSD1351_drawRGBBitmap(int16_t x, int16_t y, const uint16_t pcolors[], int16_t w,
                     int16_t h);

  uint16_t SSD1351_color565(uint8_t r, uint8_t g, uint8_t b);

  /**********************************************************************/
  /*!
    @brief  Draw to the screen/framebuffer/etc.

    @param  x    X coordinate in pixels
    @param  y    Y coordinate in pixels
    @param color  16-bit pixel color.
  */
  /**********************************************************************/
  void SSD1351_drawPixel(int16_t x, int16_t y, uint16_t color);

  void SSD1351_writeFillRect(int16_t x, int16_t y, int16_t w, int16_t h,
                             uint16_t color);
  void SSD1351_writeFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color);
  void SSD1351_writeFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color);
  void SSD1351_writeLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                         uint16_t color);

  // BASIC DRAW API

  void SSD1351_drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color);
  void SSD1351_drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color);
  void SSD1351_fillRect(int16_t x, int16_t y, int16_t w, int16_t h,
                        uint16_t color);
  void SSD1351_fillScreen(uint16_t color);
  // Optional and probably not necessary to change
  void SSD1351_drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1,
                        uint16_t color);
  void SSD1351_drawRect(int16_t x, int16_t y, int16_t w, int16_t h,
                        uint16_t color);

  // These exist only with Adafruit_GFX (no subclass overrides)
  void SSD1351_drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);
  void SSD1351_drawCircleHelper(int16_t x0, int16_t y0, int16_t r, uint8_t cornername,
                        uint16_t color);
  void SSD1351_fillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);
  void SSD1351_fillCircleHelper(int16_t x0, int16_t y0, int16_t r, uint8_t cornername,
                        int16_t delta, uint16_t color);
  void SSD1351_drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2,
                    int16_t y2, uint16_t color);
  void SSD1351_fillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2,
                    int16_t y2, uint16_t color);
  void SSD1351_drawRoundRect(int16_t x0, int16_t y0, int16_t w, int16_t h,
                     int16_t radius, uint16_t color);
  void SSD1351_fillRoundRect(int16_t x0, int16_t y0, int16_t w, int16_t h,
                     int16_t radius, uint16_t color);
  void SSD1351_drawChar(int16_t x, int16_t y, unsigned char c, uint16_t color,
                uint16_t bg, uint8_t size_x, uint8_t size_y);

  size_t SSD1351_write(uint8_t c);
  size_t SSD1351_writestr(const char *str);
  
  void SSD1351_setTextSize(uint8_t sx, uint8_t sy);

  void SSD1351_setCursor(int16_t x, int16_t y);
  
  void SSD1351_setTextColor(uint16_t c);
   
#endif /* SSD1351_H_ */