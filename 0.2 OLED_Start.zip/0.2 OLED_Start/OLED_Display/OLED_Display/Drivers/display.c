/*File:	display.c
 * Program Description:		Drivers for SSD1351 OLED Display Controller 
 * Hardware Description:	1.5" RGD SSD1351 OLED Display (https://www.waveshare.com/1.5inch-rgb-oled-module.htm)
*/

#include "OLED_Display/Graphics/images.h"
#include "OLED_Display/Drivers/display.h"
#include "OLED_Display/Drivers/SSD1351.h"

//#include "Pressure/Control/pump.h"
//#include "Pressure/Monitor/psi_sensor.h"	// Needed for psi value display
//#include "Real_Time_Clock/DS3231.h"

// DISPLAY VARIABLE FOR SOFTWARE VERSION
static char software_version[] = "V1.6.3";	// SOFTWARE VERSION

// DISPLAY VARIABLES FOR PRESSURE MONITORING
static char units_psi_text[5] = "PSI: ";
static char pressure_text[3] = "  0";

void display_slash_screen(void){
	// COMPANY SPLASH SCREEN
	SSD1351_drawRGBBitmap(0,0,image_data_company_trademark,128,128);
}

void display_alert(void){SSD1351_drawRGBBitmap(65,80,image_data_alert_22x22,22,22);}

void display_no_alert(void){
	SSD1351_drawRect(65,80,22,22,SSD1351_BLACK);
	SSD1351_fillRect(66,81,20,20,SSD1351_WHITE);
}

void display_valve0_on_status(void){SSD1351_drawRGBBitmap(90,3,image_data_arrow_right_22x22,22,22);}
	
void display_valve0_off_status(void){
	SSD1351_drawRect(90,3,22,22,SSD1351_BLACK);
	SSD1351_fillRect(91,4,20,20,SSD1351_WHITE);				// Wipe the area with white
	}

void display_valve1_on_status(void){SSD1351_drawRGBBitmap(3,3,image_data_arrow_left_22x22,22,22);}

void display_valve1_off_status(void){
	SSD1351_drawRect(3,3,22,22,SSD1351_BLACK);
	SSD1351_fillRect(4,4,20,20,SSD1351_WHITE);				// Wipe the area with white
	}

void display_pump_on_status(void){SSD1351_fillCircle(101,33,4,SSD1351_GREEN);};

void display_pump_off_status(void){SSD1351_fillCircle(101,33,4,SSD1351_RED);};

void display_day_mode_status(void){SSD1351_drawRGBBitmap(103,103,image_data_sun_22x22,22,22);};

void display_night_mode_status(void){SSD1351_drawRGBBitmap(103,103,image_data_moon_22x22,22,22);};

void display_pressure(void){
	// CLEAR OUT DISPLAY AREA FOR PRESSURE VALUE
	SSD1351_fillRect(61,5,17,7,SSD1351_WHITE);
	// DISPLAY VALUE
	SSD1351_setCursor(61,5);
	SSD1351_setTextSize(1,1);
	SSD1351_setTextColor(SSD1351_BLACK);
	//sprintf("XXX");		// %UNSIGNED DECIMAL INTEGER (SHORT)
	SSD1351_writestr(pressure_text);
}

// DISPLAY VARIABLES FOR SET PRESSURE
static char set_psi_text[5] = "SET: ";
static char set_pressure_text[3] = "  0";
void display_set_pressure(void){
	
	SSD1351_fillRect(61,18,17,7,SSD1351_WHITE);				// CLEAR OUT DISPLAY AREA
	// DISPLAY SET PRESSURE VALUE
	SSD1351_setCursor(61,18);
	SSD1351_setTextSize(1,1);
	SSD1351_setTextColor(SSD1351_RED);
	sprintf(set_pressure_text,"%3d",100); //&systemPump->setPressure);		// %UNSIGNED DECIMAL INTEGER (SHORT)		// CAN WE RESTRICT THIS TO ONLY PRINT (3) DIGITS?
	SSD1351_writestr(set_pressure_text);
}

/*
// DISPLAY VARIABLES FOR RTC
static char hour_text[2]			= "00";
static char minute_text[2]			= "00";
static char second_text[2]			= "00";
static uint8_t prev_time_second		= 0;
static uint8_t prev_time_min		= 0;
static uint8_t prev_time_hour		= 0;

void display_time_update(void){
	
	getDS3231time();
		
	if (second != prev_time_second){												// If seconds has changed value; printout
		// DIPLAY TIME (1 FONT)
		SSD1351_setTextSize(1,1);
		SSD1351_setTextColor(SSD1351_BLACK);
		SSD1351_fillRect(87,118,11,7,SSD1351_WHITE);		// CLEAR OUT DISPLAY AREA
		SSD1351_setCursor(87,118);
			
		sprintf(second_text,"%02d", second);
		SSD1351_writestr(second_text);
		
		prev_time_second = second;												//	if the time has changed and printed, reset the old time.
	}	// end of of seconds change
	
	if (minute != prev_time_min){
		SSD1351_setTextSize(1,1);
		SSD1351_setTextColor(SSD1351_BLACK);
		SSD1351_fillRect(71,118,15,7,SSD1351_WHITE);		// CLEAR OUT DISPLAY AREA
		SSD1351_setCursor(71,118);
				
		sprintf(minute_text,"%02d",minute);
		SSD1351_writestr(minute_text);
		SSD1351_writestr(":");
		prev_time_min = minute;												//	if the time has changed and printed, reset the old time.
	}	// end of of minutes change
	
	if (hour != prev_time_hour){
		SSD1351_setTextSize(1,1);
		SSD1351_setTextColor(SSD1351_BLACK);
		SSD1351_fillRect(54,118,15,7,SSD1351_WHITE);		// CLEAR OUT DISPLAY AREA
		SSD1351_setCursor(54,118);
				
		sprintf(hour_text,"%02d", hour);
		SSD1351_writestr(hour_text);
		SSD1351_writestr(":");
		prev_time_hour = hour;												//	if the time has changed and printed, reset the old time.
	}	// end of of hours change
}	// END TIME UPDATE
*/

void display_psi_text(void){
	
	SSD1351_setTextSize(1,1);
	SSD1351_setTextColor(SSD1351_BLACK);
	SSD1351_setCursor(36,5);
	SSD1351_writestr(units_psi_text);
}

void display_set_text(void){
	
	SSD1351_setTextSize(1,1);
	SSD1351_setTextColor(SSD1351_BLACK);
	SSD1351_setCursor(36,18);
	SSD1351_writestr(set_psi_text);
	display_set_pressure();							// DISPLAY THE SET PRESSURE VALUE
}

void display_software_version(void){
	
	// DISPLAY SOFTWARE VERSION
	SSD1351_setCursor(36,31);
	SSD1351_setTextSize(1,1);
	SSD1351_setTextColor(SSD1351_MAROON);
	SSD1351_writestr(software_version);
}

void display_gui_background(void){	// PRINOUT GUI BACKGROUND
	
	SSD1351_drawRGBBitmap(0, 0,image_data_gui_background, SSD1351_WIDTH, SSD1351_HEIGHT);
	display_psi_text();
	display_pressure();
	display_set_text();
	display_software_version();
}