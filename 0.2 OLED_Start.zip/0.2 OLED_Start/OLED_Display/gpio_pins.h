#ifndef GPIO_PINS_H_INCLUDED
#define GPIO_PINS_H_INCLUDED

#include <hal_gpio.h>

// SAMD21 HAS 8 PIN FUNCTIONS
#define GPIO_PIN_FUNCTION_A 0
#define GPIO_PIN_FUNCTION_B 1
#define GPIO_PIN_FUNCTION_C 2
#define GPIO_PIN_FUNCTION_D 3
#define GPIO_PIN_FUNCTION_E 4
#define GPIO_PIN_FUNCTION_F 5
#define GPIO_PIN_FUNCTION_G 6
#define GPIO_PIN_FUNCTION_H 7

/*--------------------------------------------------------------------------------------------------------------------------------------
GENERAL NOTES
----------------------------------------------------------------------------------------------------------------------------------------
1. Since the on board LED shares a pad connection with the SPI connection to the OLED,
it has been removed from PA17 as a general blink indication.
#define LED_BUILTIN		GPIO(GPIO_PORTA, 17)		// FLASHER						(D13)		ONBOARD ORANGE LED		[ REMOVED ]
2. MISO pin for SERCOM 1 PAD 3 is not utilized given the one way relationship between MCU and SSD1351
*/

/*DIGITAL INPUT PINS								DESCRIPTION						BOARD LABEL		NOTES
----------------------------------------------------------------------------------------------------------------------------------------*/
// EXTERNAL INTERRUPT PINS
// #define LOW_LVL_PIN			GPIO(GPIO_PORTA, 20)		// LOW-LEVEL FLOAT SWITCH		(D9)			PULLED HIGH -> LOW; DETECT FALLING
// #define MENU_BUTTON_PIN		GPIO(GPIO_PORTA, 11)		// MODE BUTTON					(A2)			PULLED HIGH -> LOW; DETECT FALLING
// #define ENTER_BUTTON_PIN	GPIO(GPIO_PORTA, 10)		// SET BUTTON BUTTON			(A3)			PULLED HIGH -> LOW; DETECT FALLING
// #define UP_BUTTON_PIN		GPIO(GPIO_PORTB, 14)		// (+) POSITIVE BUTTON			(A4)			PULLED HIGH -> LOW; DETECT FALLING
// #define DOWN_BUTTON_PIN		GPIO(GPIO_PORTB, 15)		// (-) NEGATIVE BUTTON			(A5)			PULLED HIGH -> LOW; DETECT FALLING

/* DIGITAL OUTPUT PIN								DESCRIPTION						BOARD LABEL		NOTES
----------------------------------------------------------------------------------------------------------------------------------------*/
//#define PUMP_0_PIN			GPIO(GPIO_PORTB, 10)		// PUMP RELAY					(D2)			MAIN SYSTEM PUMP
//#define ALARM_0_PIN			GPIO(GPIO_PORTA, 21)		// AUDIBLE ALARM				(D10)			SET THIS UP AS PWM FOR VARYING TONES
//#define ALARM_1_PIN			GPIO(GPIO_PORTA, 22)		// ALARM OUTPUT					(XXX)			PROGRAMMABLE ALARM OUTPUT

// VALVE OUTPUT PINS
//#define VALVE_0_PIN			GPIO(GPIO_PORTA,  4)		// VALVE 0 RELAY				(D6)			AUTO-PRIME/RECIRCULATION
//#define VALVE_1_PIN			GPIO(GPIO_PORTA,  5)		// VALVE 1 RELAY				(D5)			WATER SUPPLY ZONE 1
//#define VALVE_2_PIN			GPIO(GPIO_PORTA,  6)		// VALVE 2 RELAY				(D7)			WATER SUPPLY ZONE 2
//#define VALVE_3_PIN			GPIO(GPIO_PORTA,  7)		// VALVE 3 RELAY				(D4)			WATER SUPPLY ZONE 3
//#define VALVE_4_PIN			GPIO(GPIO_PORTA,  8)		// VALVE 4 RELAY				(XX)			WATER SUPPLY ZONE 4
//#define VALVE_5_PIN			GPIO(GPIO_PORTA,  9)		// VALVE 5 RELAY				(A6)			WATER SUPPLY ZONE 5

/*SERIAL COMMUNICATIONS								DESCRIPTION						BOARD LABEL		NOTES
----------------------------------------------------------------------------------------------------------------------------------------*/
// SERCOM 5 | USART TARGET DEVICE STDIO
#define TX_PIN				GPIO(GPIO_PORTB,  2)		// TRANSMIT 					(SDA)			SERIAL TO USB CONVERTER
#define RX_PIN				GPIO(GPIO_PORTB,  3)		// RECEIVE						(SCL)			USB CONVERTER TO SERIAL

// SERCOM 2 | SPI OLED DISPLAY CONTROLLER SSD1351
#define OLED_RST_PIN		GPIO(GPIO_PORTA,  4)		// DISPLAY RESET				(A3)			FROM TARGET DEVICE
#define OLED_MOSI_PIN		GPIO(GPIO_PORTA, 12)		// MCU OUT SLAVE IN				(MOSI)
#define OLED_SCK_PIN		GPIO(GPIO_PORTA, 13)		// SPI SERIAL CLOCK				(SCK)		
#define OLED_CS_PIN			GPIO(GPIO_PORTA, 14)		// CHIP SELECT (CS)				(MISO)			MISO DISABLED		
#define OLED_DC_PIN			GPIO(GPIO_PORTA, 16)		// DATA / COMMAND (DC)			(D13)

/*
This typical SPI pin is unused in this display application.
This is because there is a one-way master relationship between
the MCU and the OLED Display Controller. MCU -> SSD1351 (MOSI Only)

#define OLED_MISO_PIN		GPIO(GPIO_PORTA, 14)		// MISO							(DXX)			MCU IN SLAVE OUT
*/

// I2C FOR ADC
//#define ADC_SDA_PIN			GPIO(GPIO_PORTB, 8)			// DERIAL DATA					(D18)
//#define ADC_SCL_PIN			GPIO(GPIO_PORTB, 9)			// SERIAL CLOCK					(D19)

#endif

