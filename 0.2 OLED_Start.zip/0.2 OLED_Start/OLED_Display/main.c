/*File:	main.c
 * Author:	Integrated Bioengineering, LLC.
 * Processor: SAMD51J19A @ 120MHz, 3.3v
 * Program: Main Application File
 * Compiler: ARM-GCC Microchip Studio
 * Program Version: 0.2
 * Program Description: OLED Display Startup
 * Hardware Description:	
		1 x Adafruit Metro M4 Development Board
		1 x Waveshare 1.5" RGB OLED Display, 4-wire SPI
		1 x	Atmel ICE Debugger													(https://www.microchip.com/en-us/development-tool/atatmel-ice)
		4 x	push-button for menu interfacing 
		
		Additional Hardware Descriptions in Implementation Files.
		
Copyright (c) 2024 Integrated Bioengineering, LLC. and its subsidiaries.
................................................................................................*/

#include "driver_init.h"

#define DELAY_MS 100  // 100 milliseconds delay
#define CYCLES 20     // Number of cycles to run the loop

int main(void)
{
	// Initialize System and Peripherals
	system_init();

	while (1) {
		
	// Print BMP of Company Logo [128 x 128] stored in memory
	display_slash_screen();
	printf("Displaying Company Splash Screen");
	delay_ms(3000);
	
	// Fills Display Black
	SSD1351_fillScreen(SSD1351_BLACK);
	printf("Display All Black");	
	
	display_gui_background();
	display_pressure();
	delay_ms(1000);
	
	display_alert();
	delay_ms(1000);
	display_no_alert();
	delay_ms(500);
	
    // Loop for 30 cycles
    for (int i = 0; i < CYCLES; i++){
	    // Display pump on status
	    display_pump_on_status();
	    // Delay for 100 milliseconds
	    delay_ms(DELAY_MS);
	    
	    // Display pump off status
	    display_pump_off_status();
	    // Delay for 100 milliseconds
	    delay_ms(DELAY_MS);
    }	// Loop for 30 cycles (3s)
	
	
	// Display Valve Status Graphics
	display_valve0_on_status();
	delay_ms(500);
	display_valve0_off_status();
	delay_ms(500);
	display_valve1_on_status();
	delay_ms(500);
	display_valve1_off_status();
	delay_ms(500);
	
	// Display Period Mode Graphics
	delay_ms(500);
	display_day_mode_status();
	delay_ms(1000);
	display_night_mode_status();
	delay_ms(3000);
	
	} // End Application
} // End Setup
